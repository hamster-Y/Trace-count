package org.processmining.plugins;

import org.processmining.contexts.uitopia.annotations.UITopiaVariant;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.framework.plugin.annotations.Plugin;
import org.processmining.framework.plugin.annotations.PluginVariant;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.semantics.petrinet.Marking;
import org.deckfour.uitopia.api.event.TaskListener;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.jbpt.petri.PetriNet;
import org.processmining.contexts.uitopia.UIPluginContext;

import org.processmining.plugins.kutoolbox.eventlisteners.PluginEventListener;
import org.processmining.plugins.kutoolbox.eventlisteners.PluginEventListenerUI;
import org.processmining.plugins.loggenerator.simulators.PetriNetSimulator;
import org.processmining.plugins.loggenerator.simulators.PetriNetSimulatorComplete;
import org.processmining.plugins.loggenerator.simulators.PetriNetSimulatorDistinct;
import org.processmining.plugins.loggenerator.simulators.PetriNetSimulatorRandom;
import org.processmining.plugins.loggenerator.ui.ActivityConfigurationPanel;
import org.processmining.plugins.loggenerator.ui.MainConfigurationPanel;
import org.processmining.plugins.loggenerator.ui.ParametersWizard;
import org.processmining.plugins.loggenerator.ui.TraceTimingsPanel;
import org.processmining.plugins.loggenerator.utils.GeneratorSettings;
import org.processmining.plugins.loggenerator.utils.GeneratorSettings.SimulationAlgorithm;
import org.processmining.plugins.loggenerator.utils.LogBuilder;
import java.util.List;
import java.util.Random;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.kutoolbox.eventlisteners.PluginEventListener;
import org.processmining.plugins.kutoolbox.exceptions.OperationCancelledException;
import org.processmining.plugins.kutoolbox.utils.PetrinetUtils;
import org.processmining.plugins.loggenerator.utils.GeneratorSettings;
import org.processmining.plugins.loggenerator.utils.LogBuilder;
import org.processmining.plugins.yapetrinetreplayer.types.ReplayState;
import org.processmining.plugins.yapetrinetreplayer.types.ReplayStateChain;
import org.processmining.processtree.ProcessTree;
import org.processmining.ptconversions.pn.ProcessTree2Petrinet;
import org.processmining.ptconversions.pn.ProcessTree2Petrinet.InvalidProcessTreeException;
import org.processmining.ptconversions.pn.ProcessTree2Petrinet.NotYetImplementedException;
import org.processmining.ptconversions.pn.ProcessTree2Petrinet.PetrinetWithMarkings;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
public class HelloWorld {
        @Plugin(
                name = "Trace count", 
                parameterLabels = {"PetriNet"}, 
                returnLabels = { "number of traces" }, 
                returnTypes = { JFrame.class }, 
                userAccessible = true, 
                help = "Produces the string: 'Hello world'"
        )
        @PluginVariant(requiredParameterLabels = {0})
        @UITopiaVariant(
                affiliation = "My company", 
                author = "My name", 
                email = "My e-mail address"
        )
        
        public static JFrame main(UIPluginContext context, Object obj) throws NotYetImplementedException, InvalidProcessTreeException {
        	Petrinet Net=null;
        	if(obj instanceof Petrinet) {
        		Net=(Petrinet) obj;
        		
        	}else {
        		ProcessTree processtree=(ProcessTree) obj;
        		Net =  ProcessTree2Petrinet.convert(processtree).petrinet;
        	}
//            ParametersWizard conf = new ParametersWizard(context, petriNet);
            PluginEventListenerUI pluginEventListenerUI = new PluginEventListenerUI(context);
            
            try {
//              conf.show();
              
              GeneratorSettings settings =new GeneratorSettings();
            	
			System.out.println("**************"+Net);
			        MainConfigurationPanel parameterPanel = new MainConfigurationPanel(settings, Net);
//			        result = context.showWizard("Log Generation Settings", true, false, (JComponent)parameterPanel);
			        
			        settings = parameterPanel.getSettings();
			        String input = JOptionPane.showInputDialog(null, "ѭ�����ƴ���Ϊ��");
			        int inputValue = Integer.parseInt(input);

			        // ���û����������ֵ���ݸ� settings.setMaxTimesMarkingSeen()
			        settings.setMaxTimesMarkingSeen(inputValue);
//			        settings.setMaxTimesMarkingSeen(1);
			      settings.setSimulationMethod(SimulationAlgorithm.Complete);
			      
			        TraceTimingsPanel parameterPanel2 = new TraceTimingsPanel(settings);
//			        result = context.showWizard("Trace Timing Settings", false, false, (JComponent)parameterPanel);
			        settings = parameterPanel2.getSettings();
			        
			      
			      
			        ActivityConfigurationPanel mappingPanel = new ActivityConfigurationPanel(settings, Net);
//			        result = context.showWizard("Activity Mapping and Weights", false, true, mappingPanel);
			        
			       
			      
              
              pluginEventListenerUI.logMessage("Simulating...");
              XLog log = generate(Net, null, settings, (PluginEventListener)pluginEventListenerUI);
              pluginEventListenerUI.logMessage("Finishing...");
              String message = "��ģ�͵Ĺ켣��Ϊ: " + log.size();
              int a=0;
              for (XTrace trace : log) {
            	  a+=1;
              }
System.out.println("****************"+a);
System.out.println("****************"+settings.getMaxTimesMarkingSeen());
              // ����һ���µĵ���
              JFrame frame = new JFrame("�켣������");
              frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

              // ����һ����ǩ����ʾ��Ϣ
              JLabel label = new JLabel(message);
              label.setHorizontalAlignment(SwingConstants.CENTER);
              frame.getContentPane().add(label);

              // ���ô��ڴ�С�Ϳɼ���
              frame.setSize(500, 200);
              frame.setLocationRelativeTo(null); // �ô��ھ�����ʾ
              frame.setVisible(true);

              return frame;
            } catch (Exception e) {
            	e.printStackTrace();
              context.getFutureResult(0).cancel(true);
              JFrame frame = new JFrame("Error");
              frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

              // ����һ����ǩ����ʾ��Ϣ
              JLabel label = new JLabel("����켣��ʧ��"+e.getMessage());
              label.setHorizontalAlignment(SwingConstants.CENTER);
              frame.getContentPane().add(label);

              // ���ô��ڴ�С�Ϳɼ���
              frame.setSize(300, 100);
              frame.setLocationRelativeTo(null); // �ô��ھ�����ʾ
              frame.setVisible(true);

              return frame;
            } 
          }
                
        public static XLog generate(Petrinet petriNet, Marking marking, GeneratorSettings settings, PluginEventListener optionalListener) throws Exception {
            PetriNetSimulatorRandom petriNetSimulatorRandom;
            PetriNetSimulatorComplete petriNetSimulatorComplete;
            PetriNetSimulatorDistinct petriNetSimulatorDistinct;
            LogBuilder logBuilder = new LogBuilder(settings);
//            PetriNetSimulator petriSimulator = null;
            GeneratorSettings.SimulationAlgorithm selectedAlgorithm = settings.getSimulationMethod();
            switch (selectedAlgorithm) {
              case Random:
                petriNetSimulatorRandom = new PetriNetSimulatorRandom(settings, petriNet, logBuilder, marking, optionalListener);
                petriNetSimulatorRandom.simulateLog();
                logBuilder.finalizeLog();
                return logBuilder.getLog();
              case Complete:
                petriNetSimulatorComplete = new PetriNetSimulatorComplete(settings, petriNet, logBuilder, marking, optionalListener);
                petriNetSimulatorComplete.simulateLog();
                logBuilder.finalizeLog();
                return logBuilder.getLog();
              case Distinct:
                petriNetSimulatorDistinct = new PetriNetSimulatorDistinct(settings, petriNet, logBuilder, marking, optionalListener);
                petriNetSimulatorDistinct.simulateLog();
                logBuilder.finalizeLog();
                return logBuilder.getLog();
            } 
            return null;
          }
}